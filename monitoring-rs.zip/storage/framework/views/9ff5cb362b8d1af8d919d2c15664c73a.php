<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Laporan Monitoring <?php echo e($title); ?></title>
    <style>
        body {
            font-family: 'Helvetica', sans-serif;
            font-size: 7px;
            margin: 0;
            padding: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 3px;
        }

        th,
        td {
            border: 1px solid #999;
            /* PERKECIL PADDING SEL */
            padding: 1px 2px;
            /* Padding atas/bawah 1px, kiri/kanan 2px */
            text-align: left;
            vertical-align: top;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-align: center;
        }

        .header-table {
            margin-bottom: 5px;
            /* Mengurangi margin */
        }

        .header-table td {
            border: none;
            padding: 1px 0;
        }

        .text-center {
            text-align: center;
        }

        .text-right {
            text-align: right;
        }

        .bold {
            font-weight: bold;
        }

        .no-border,
        .no-border td {
            border: none;
        }

        .w-50 {
            width: 50%;
        }

        h2 {
            text-align: center;
            margin: 0 0 5px 0;
        }

        h3 {
            text-align: center;
            margin: 5px 0 5px 0;
            /* MENGURANGI MARGIN */
        }

        .page-break {
            page-break-after: always;
        }

        .nutrition-lab-table {
            width: 100%;
            /* Lebar penuh */
            border-collapse: collapse;
            /* Hapus spasi antar border */
            border: 1px solid black;
            /* Border luar */
            font-size: 8px;
            /* Sesuaikan ukuran font */
            margin-bottom: 5px;
            /* Jarak bawah */
        }

        .nutrition-lab-table th,
        .nutrition-lab-table td {
            border: 1px solid black;
            /* Border dalam */
            padding: 3px;
            /* Sedikit padding */
            vertical-align: top;
            /* Rata atas */
        }

        .nutrition-lab-table th {
            font-weight: bold;
            text-align: center;
            background-color: #f2f2f2;
            /* Warna header */
        }

        /* Atur tinggi area konten */
        .nutrition-content-cell {
            height: 80px;
            /* Sesuaikan tinggi sesuai kebutuhan */
        }

        .lab-content-cell {
            height: 60px;
            /* Sesuaikan tinggi sesuai kebutuhan */
        }

    </style>
</head>
<body>
    <table width="100%" style="margin-bottom: 5px;">
        <tr>
            <td style="width: 15%; text-align: center;">
                <?php if(!empty($setting->logo)): ?>
                <img src="data:image/png;base64,<?php echo e(base64_encode($setting->logo)); ?>" style="height: 60px;">
                <?php endif; ?>
            </td>
            <td style="text-align: center; vertical-align: middle;">
                <div style="font-size: 14px; font-weight: bold;"><?php echo e($setting->nama_instansi ?? 'Nama Instansi'); ?></div>
                <div style="font-size: 10px;"><?php echo e($setting->alamat_instansi ?? '-'); ?></div>
                <div style="font-size: 10px;">
                    <?php echo e($setting->kabupaten ?? ''); ?>, <?php echo e($setting->propinsi ?? ''); ?>

                </div>
                <div style="font-size: 9px;">Telp: <?php echo e($setting->kontak ?? '-'); ?> | Email: <?php echo e($setting->email ?? '-'); ?></div>
            </td>
        </tr>
    </table>
    <hr style="margin: 4px 0;">
    
    <table style="width:100%; font-size:10px; border-collapse:collapse;">
        <tr>
            
            <td style="width:30%; vertical-align:top;">
                <table style="width:100%; font-size:10px; border-collapse:collapse;">
                    <tr>
                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Nama Bayi</td>
                        <td style="padding:4px; font-weight:bold;"><?php echo e($patient->nm_pasien ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Jenis Kelamin</td>
                        <td style="padding:4px;"><?php echo e($patient->jk === 'L' ? 'Laki-laki' : 'Perempuan'); ?></td>
                    </tr>
                    <tr>
                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Umur Bayi</td>
                        <td style="padding:4px;"><?php echo e($umur_bayi ?? 'N/A'); ?> hari</td>
                    </tr>
                    <tr>
                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Tanggal</td>
                        <td style="padding:4px; font-weight:bold;"><?php echo e($cycle->start_time ? \Carbon\Carbon::parse($cycle->start_time)->isoFormat('dddd, D MMMM YYYY') : 'N/A'); ?></td>
                    </tr>
                </table>
            </td>

            
            <td style="width:70%; vertical-align:top;">
                <table style="width:100%; font-size:10px; border-collapse:collapse;">
                    
                    <tr>
                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Tanggal Lahir</td>
                        <td style="padding:4px;"><?php echo e($patient->tgl_lahir ? \Carbon\Carbon::parse($patient->tgl_lahir)->isoFormat('D MMM YYYY') : 'N/A'); ?></td>

                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Hari Rawat Ke</td>
                        <td style="padding:4px;"><?php echo e($hari_rawat_ke ?? 'N/A'); ?></td>

                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">No RM</td>
                        <td style="padding:4px;"><?php echo e($patient->no_rkm_medis ?? 'N/A'); ?></td>

                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Berat Lahir</td>
                        <td style="padding:4px;"><?php echo e($patient->berat_lahir ?? 'N/A'); ?> <?php echo e($patient->berat_lahir ? 'gram' : ''); ?></td>
                    </tr>

                    
                    <tr>
                        <?php if($isPICU): ?>
                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Umur Kehamilan</td>
                        <td style="padding:4px;"><?php echo e($patient->umur_kehamilan ?? 'N/A'); ?> minggu</td>
                        <?php endif; ?>
                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Diagnosis</td>
                        <td style="padding:4px;" colspan="5">
                            <?php $__empty_1 = true; $__currentLoopData = $diagnosaPasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diagnosa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php echo e($loop->iteration); ?>. <?php echo e($diagnosa); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            N/A
                            <?php endif; ?>
                        </td>
                    </tr>

                    
                    <tr>
                        <?php if($isPICU): ?>
                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Umur Koreksi</td>
                        <td style="padding:4px;">N/A</td>
                        <?php endif; ?>

                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Asal Ruangan</td>
                        <td style="padding:4px;"><?php echo e($patient->asal_bangsal ?? 'N/A'); ?></td>

                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Dokter DPJP</td>
                        <td style="padding:4px; max-width:200px; word-wrap:break-word;" colspan="3">
                            <?php if($dpjpDokters->isNotEmpty()): ?>
                            <?php echo implode(', ', $dpjpDokters->pluck('nm_dokter')->toArray()); ?>

                            <?php else: ?>
                            -
                            <?php endif; ?>
                        </td>
                    </tr>

                    
                    <tr>
                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Non Rujukan</td>
                        <td style="padding:4px;"><?php echo e($patient->non_rujukan ?? 'N/A'); ?></td>

                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Jaminan</td>
                        <td style="padding:4px;"><?php echo e($patient->jaminan ?? 'N/A'); ?></td>

                        <?php if($isPICU): ?>
                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Cara Persalinan</td>
                        <td style="padding:4px;"><?php echo e($patient->cara_persalinan ?? 'N/A'); ?></td>
                        <?php endif; ?>

                        <td style="background:#f0f0f0; padding:4px; font-weight:bold;">Rujukan</td>
                        <td style="padding:4px;"><?php echo e($patient->rujukan ?? 'N/A'); ?></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <h2><?php echo e($title); ?></h2>
    <hr>
    <table class="border" style="width: 100%; table-layout: fixed; border-spacing: 0;">
        <tr>
            <td style="width: 33.3%; vertical-align: top; padding: 0 1px;">
                <h4 style="margin: 0; font-size: 8px; font-weight: bold; text-align: center; line-height: 1;">
                    Tanda Vital
                </h4>
                <?php if($chartVitalsBase64): ?>
                <img src="<?php echo e($chartVitalsBase64); ?>" style="width: 100%; max-height: 80px; object-fit: contain;">
                <?php endif; ?>
            </td>
            <td style="width: 33.3%; vertical-align: top; padding: 0 1px;">
                <h4 style="margin: 0; font-size: 8px; font-weight: bold; text-align: center; line-height: 1;">
                    Suhu
                </h4>
                <?php if($chartTempBase64): ?>
                <img src="<?php echo e($chartTempBase64); ?>" style="width: 100%; max-height: 80px; object-fit: contain;">
                <?php endif; ?>
            </td>
            <td style="width: 33.3%; vertical-align: top; padding: 0 1px;">
                <h4 style="margin: 0; font-size: 8px; font-weight: bold; text-align: center; line-height: 1;">
                    Tekanan Darah
                </h4>
                <?php if($chartBpBase64): ?>
                <img src="<?php echo e($chartBpBase64); ?>" style="width: 100%; max-height: 80px; object-fit: contain;">
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <table style="width: 100%; table-layout: fixed; border-collapse: collapse;">
        <tr>
            <!-- Kolom Kiri: Masalah Klinis + Program Terapi -->
            <td style="width: 20%; vertical-align: top; padding: 4px; border: 1px solid #ccc; background: #f9fafb;">
                <!-- Masalah Klinis Aktif -->
                <strong style="display: block; background: #e9ecef; padding: 3px 4px; border-radius: 4px; margin-bottom: 4px; font-size: 9px; text-align: center;">
                    Masalah Klinis Aktif
                </strong>
                <div style="margin-top: 4px; font-size: 8px; line-height: 1.1;">
                    <?php echo nl2br(e($therapySections['masalahOnly'])); ?>

                </div>

                <!-- Garis pembatas halus -->
                <hr style="border: 0; border-top: 1px dashed #ccc; margin: 6px 0;">

                <!-- Program Terapi -->
                <strong style="display: block; background: #e9ecef; padding: 3px 4px; border-radius: 4px; margin-bottom: 4px; font-size: 9px; text-align: center;">
                    Program Terapi
                </strong>
                <div style="margin-top: 4px; font-size: 8px; line-height: 1.1;">
                    <?php echo nl2br(e($therapySections['programOnly'])); ?>

                </div>
            </td>

            <!-- Kolom Kanan: Hemodinamik + Observasi Apnea -->
            <td style="width: 65%; vertical-align: top; padding-left: 6px;">
                <h3 style="background-color: #dee2e6; padding: 4px; border-radius: 4px; font-size: 10px; margin-bottom: 2px;">
                    Masalah Klinis & Data Hemodinamik / Apnea
                </h3>
                <?php
                // Ambil semua jam yang memang punya nilai di salah satu parameter hemodinamik
                $activeHemoHours = collect($reportHours)->filter(function ($hour) use ($hemoMatrix) {
                foreach ($hemoMatrix as $paramKey => $values) {
                if (!empty($values[$hour])) {
                return true;
                }
                }
                return false;
                })->values();
                ?>

                <!-- Tabel Hemodinamik -->
                <table style="width: 100%; table-layout: fixed; font-size: 8px; border-collapse: collapse;" border="1">
                    <thead>
                        <tr>
                            <th style="width: 110px;" rowspan="2">Parameter</th>
                            <th class="text-center" colspan="<?php echo e(count($activeHemoHours)); ?>">JAM / TIME</th>
                        </tr>
                        <tr>
                            <?php $__currentLoopData = $activeHemoHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th style="width: 26px;" class="text-center"><?php echo e($hour); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $hemoParameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paramKey => $paramName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="font-weight: bold; padding: 2px 4px;"><?php echo e($paramName); ?></td>
                            <?php $__currentLoopData = $activeHemoHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="text-center" style="padding: 2px 2px;">
                                <?php if(!empty($hemoMatrix[$paramKey][$hour])): ?>
                                <?php echo e($hemoMatrix[$paramKey][$hour]); ?>

                                <?php endif; ?>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <!-- Tabel Observasi Apnea Warna -->
                <?php if($activeObservationHours->isNotEmpty()): ?>
                <table style="width: 100%; table-layout: fixed; font-size: 8px; margin-top: 4px; border-collapse: collapse;" border="1">
                    <thead>
                        <tr>
                            <th style="width: 110px; text-align: left;">Parameter</th>
                            <?php $__currentLoopData = $activeObservationHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th style="width: 26px;" class="text-center"><?php echo e($hour); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $observationParameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paramKey => $paramName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count(array_filter($observationMatrix[$paramKey])) > 0): ?>
                        <tr>
                            <td style="font-weight: bold; padding: 2px 4px;"><?php echo e($paramName); ?></td>
                            <?php $__currentLoopData = $activeObservationHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="text-center" style="padding: 2px 2px;">
                                <?php if(!empty($observationMatrix[$paramKey][$hour])): ?>
                                <?php echo e($observationMatrix[$paramKey][$hour]); ?>

                                <?php endif; ?>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>

            </td>
        </tr>
    </table>

    <table style="width: 100%; table-layout: fixed; border-collapse: collapse; margin-top: 6px;">
        <tr>
            <!-- Kolom Kiri: NUTRISI + PEMERIKSAAN LABORATORIUM -->
            <td style="width: 20%; vertical-align: top; padding: 4px; border: 1px solid #ccc; background: #f9fafb;">
                <!-- Bagian NUTRISI -->
                <strong style="display: block; background: #e9ecef; padding: 3px 4px; border-radius: 4px; margin-bottom: 4px; font-size: 9px; text-align: center;">
                    NUTRISI
                </strong>
                <table style="width: 100%; font-size: 8px; border-collapse: collapse;" border="1">
                    <thead>
                        <tr style="background-color: #f8f9fa;">
                            <th style="width: 50%; text-align: center;">ENTERAL</th>
                            <th style="width: 50%; text-align: center;">PARENTERAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="vertical-align: top; padding: 2px;">
                                <?php echo nl2br(e($therapySections['nutrisiEnteralOnly'])); ?>

                            </td>
                            <td style="vertical-align: top; padding: 2px;">
                                <?php echo nl2br(e($therapySections['nutrisiParenteralOnly'])); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>

                <hr style="border: 0; border-top: 1px dashed #ccc; margin: 6px 0;">

                <!-- Bagian PEMERIKSAAN LABORATORIUM -->
                <strong style="display: block; background: #e9ecef; padding: 3px 4px; border-radius: 4px; margin-bottom: 4px; font-size: 9px; text-align:center">
                    PEMERIKSAAN PENUNJANG
                </strong>
                <div style="font-size: 8px; line-height: 1.1;">
                    <?php echo nl2br(e($therapySections['pemeriksaanLabOnly'])); ?>

                </div>
            </td>

            <!-- Kolom Kanan: GAS DARAH + TERAPI OKSIGEN / VENTILATOR -->
            <td style="width: 65%; vertical-align: top; padding-left: 6px;">
                <!-- BAGIAN GAS DARAH -->
                <?php if($bloodGasHours->isNotEmpty()): ?>
                <h3 style="text-align: center; background-color: #dee2e6; padding: 4px; border-radius: 4px; font-size: 10px; margin-bottom: 4px;">
                    Hasil Gas Darah
                </h3>
                <table border="1" cellspacing="0" cellpadding="4" style="width: 100%; font-size: 9px; border-collapse: collapse; margin-bottom: 6px;">
                    <thead>
                        <tr style="background-color: #f8f9fa;">
                            <th style="width: 120px; text-align: left;">Parameter</th>
                            <?php $__currentLoopData = $bloodGasHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th style="text-align: center;"><?php echo e($hour); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bloodGasParameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $param => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="font-weight: bold; padding: 2px 4px;"><?php echo e($label); ?></td>
                            <?php $__currentLoopData = $bloodGasHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align: center;"><?php echo e($bloodGasMatrix[$param][$hour] ?? '-'); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>

                <!-- BAGIAN TERAPI OKSIGEN / VENTILATOR -->
                <?php if($activeVentilatorHours->isNotEmpty()): ?>
                <h3 style="background-color: #dee2e6; padding: 4px; border-radius: 4px; font-size: 10px; margin-bottom: 2px;">
                    Terapi Oksigen / Ventilator
                </h3>

                <?php $__currentLoopData = $ventilatorParams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $params): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $hasData = false;
                foreach ($params as $paramKey => $label) {
                foreach ($activeVentilatorHours as $hour) {
                if (!empty($ventilatorMatrix[$paramKey][$hour])) {
                $hasData = true;
                break 2;
                }
                }
                }
                ?>

                <?php if($hasData): ?>
                <h3 style="background-color: #e9ecef; padding: 3px 6px; border-radius: 4px; font-size: 9px; margin-top: 4px;">
                    <?php echo e($group); ?>

                </h3>

                <table style="width: 100%; table-layout: fixed; font-size: 8px; margin-top: 2px; border-collapse: collapse;" border="1">
                    <thead>
                        <tr style="background-color: #f8f9fa;">
                            <th style="width: 120px; text-align: left; padding: 2px 4px;">PARAMETER</th>
                            <?php $__currentLoopData = $activeVentilatorHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th style="width: 26px; text-align: center;"><?php echo e($hour); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $params; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paramKey => $paramLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="font-weight: bold; padding: 2px 4px;"><?php echo e($paramLabel); ?></td>
                            <?php $__currentLoopData = $activeVentilatorHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align: center;"><?php echo e($ventilatorMatrix[$paramKey][$hour] ?? ''); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </td>
        </tr>
    </table>
    <?php
    $filteredRecords = $records->filter(function ($record) {
    return
    $record->parenteralIntakes->isNotEmpty() ||
    $record->enteralIntakes->isNotEmpty() ||
    $record->intake_ogt > 0 ||
    $record->intake_oral > 0 ||
    $record->output_ngt > 0 ||
    $record->output_urine > 0 ||
    $record->output_bab > 0 ||
    $record->output_drain > 0;
    });
    ?>
    <table style="width:100%; table-layout:fixed; font-family:Arial, sans-serif; border-collapse:collapse; margin-top:5px;">
        <tr>
            <!-- Kolom Kiri -->
            <td style="width:25%; vertical-align:top; padding-right:6px;">
                
                <?php if(isset($cycle) && $filteredRecords->isNotEmpty()): ?>
                <div style="background:#d0e0ff; border-radius:8px; padding:6px; margin-bottom:6px; font-size:8px;">
                    <strong>Balance Cairan 24 Jam</strong>
                    <table style="width:100%; border-collapse:collapse; margin-top:4px; font-size:8px;">
                        <?php $__currentLoopData = [
                        ['Masuk', number_format($filteredRecords->sum(fn($r)=>$r->totalCairanMasuk()),2),'ml'],
                        ['Keluar', number_format($filteredRecords->sum(fn($r)=>$r->totalCairanKeluar()),2),'ml'],
                        ['Produksi urine', number_format($filteredRecords->sum('output_urine'),2),'ml'],
                        ['EWL', number_format($cycle->daily_iwl ?? 0,2),'ml'],
                        ['BC 24 Jam', number_format($cycle->calculated_balance_24h ?? 0,2),'ml'],
                        ['BC 24 Jam sebelumnya', number_format($previousCycle->calculated_balance_24h ?? 0,2),'ml'],
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="padding:3px 4px;"><?php echo e($row[0]); ?></td>
                            <td style="text-align:right; padding:3px 4px;"><?php echo e($row[1]); ?></td>
                            <td style="text-align:center; padding:3px 4px;"><?php echo e($row[2]); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <?php endif; ?>
                
                <div style="background:#f0f4ff; border-radius:8px; padding:6px; font-size:8px;">
                    <strong>Alat Terpasang</strong>
                    <?php if($patientDevices->isNotEmpty()): ?>
                    <ul style="padding-left:15px; margin-top:4px;">
                        <?php $__currentLoopData = $patientDevices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($device->device_name); ?>

                            <?php if($device->size): ?> (Size: <?php echo e($device->size); ?>) <?php endif; ?>
                            <?php if($device->location): ?> — <?php echo e($device->location); ?> <?php endif; ?>
                            <?php if($device->installation_date): ?>
                            <span style="color: gray;">(<?php echo e(\Carbon\Carbon::parse($device->installation_date)->format('d M Y')); ?>)</span>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php else: ?>
                    <p style="color:#666; margin-top:4px;">Belum ada alat terpasang.</p>
                    <?php endif; ?>
                </div>
            </td>

            <!-- Kolom Kanan -->
            <td style="width:80%; vertical-align:top; padding-left:6px;">
                
                <?php if($filteredRecords->isNotEmpty()): ?>
                <div style="background:#f0f4ff; border-radius:8px; padding:6px; margin-bottom:6px; font-size:8px;">
                    <h3 style="text-align: center; background-color: #dee2e6; padding: 4px; border-radius: 4px; font-size: 10px; margin-bottom: 4px;">
                        Keseimbangan Cairan per Jam
                    </h3>
                    <table style="width:100%; border-collapse:collapse; font-size:8px; margin-top:4px;">
                        <thead>
                            <tr style="background:#e0e7ff;">
                                <th style="border:1px solid #ccc; padding:2px 4px; text-align:left; width:100px;">Jenis Cairan</th>
                                <?php $__currentLoopData = $filteredRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th style="border:1px solid #ccc; padding:2px; text-align:center;"><?php echo e(date('H:i', strtotime($record->record_time))); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <th style="border:1px solid #ccc; padding:2px; text-align:center; background:#f9fafb;">TOTAL</th>
                            </tr>
                        </thead>
                        <tbody>
                        <tbody>
                            
                            <tr style="background-color:#f9fafb; font-weight:bold;">
                                <td colspan="<?php echo e(count($filteredRecords) + 2); ?>" style="padding:3px;">Parental</td>
                            </tr>
                            
                            <?php
                            $allInfusNames = collect();
                            foreach ($filteredRecords as $record) {
                            $allInfusNames = $allInfusNames->merge($record->parenteralIntakes->pluck('name'));
                            }
                            $uniqueInfusNames = $allInfusNames->unique()->values();
                            ?>
                            <?php $__currentLoopData = $uniqueInfusNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infusName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="border:1px solid #ccc; padding:2px 4px; font-style:italic;"><?php echo e($infusName); ?></td>
                                <?php $__currentLoopData = $filteredRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $infus = $record->parenteralIntakes->firstWhere('name', $infusName);
                                ?>
                                <td style="border:1px solid #ccc; text-align:center;">
                                    <?php echo e($infus ? $infus->volume : ''); ?>

                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center; font-weight:bold; background:#f9fafb;">
                                    <?php echo e($filteredRecords->sum(fn($r) => ($r->parenteralIntakes->firstWhere('name', $infusName)?->volume ?? 0))); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr style="background-color:#f9fafb; font-weight:bold;">
                                <td colspan="<?php echo e(count($filteredRecords) + 2); ?>" style="padding:3px;">Enteral</td>
                            </tr>

                            <?php
                            $allInfusNames = collect();
                            foreach ($filteredRecords as $record) {
                            $allInfusNames = $allInfusNames->merge($record->enteralIntakes->pluck('name'));
                            }
                            $uniqueInfusNames = $allInfusNames->unique()->values();
                            ?>
                            <?php $__currentLoopData = $uniqueInfusNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infusName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="border:1px solid #ccc; padding:2px 4px; font-style:italic;"><?php echo e($infusName); ?></td>
                                <?php $__currentLoopData = $filteredRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $infus = $record->enteralIntakes->firstWhere('name', $infusName);
                                ?>
                                <td style="border:1px solid #ccc; text-align:center;">
                                    <?php echo e($infus ? $infus->volume : ''); ?>

                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center; font-weight:bold; background:#f9fafb;">
                                    <?php echo e($filteredRecords->sum(fn($r) => ($r->enteralIntakes->firstWhere('name', $infusName)?->volume ?? 0))); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td style="border:1px solid #ccc;">OGT</td>
                                <?php $__currentLoopData = $filteredRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center;"><?php echo e($record->intake_ogt ?: ''); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center; font-weight:bold; background:#f9fafb;">
                                    <?php echo e($filteredRecords->sum('intake_ogt')); ?>

                                </td>
                            </tr>

                            
                            <tr>
                                <td style="border:1px solid #ccc;">Oral</td>
                                <?php $__currentLoopData = $filteredRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center;"><?php echo e($record->intake_oral ?: ''); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center; font-weight:bold; background:#f9fafb;">
                                    <?php echo e($filteredRecords->sum('intake_oral')); ?>

                                </td>
                            </tr>
                            
                            <tr style="background:#f3f4f6; font-weight:bold;">
                                <td style="border:1px solid #ccc;">TOTAL CM</td>
                                <?php $__currentLoopData = $filteredRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center;"><?php echo e($record->totalCairanMasuk()); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center;"><?php echo e($filteredRecords->sum(fn($r) => $r->totalCairanMasuk())); ?></td>
                            </tr>

                            
                            <tr style="background:#f9fafb; font-weight:bold;">
                                <td colspan="<?php echo e(count($filteredRecords) + 2); ?>" style="padding:3px;">OUTPUT (CAIRAN KELUAR)</td>
                            </tr>

                            <?php $__currentLoopData = ['output_ngt' => 'NGT','output_urine' => 'Urine','output_bab' => 'BAB','output_drain' => 'Drain']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="border:1px solid #ccc;"><?php echo e($label); ?></td>
                                <?php $__currentLoopData = $filteredRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center;"><?php echo e($record->$field ?: ''); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center; font-weight:bold; background:#f9fafb;">
                                    <?php echo e($filteredRecords->sum($field)); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            <tr style="background:#f3f4f6; font-weight:bold;">
                                <td style="border:1px solid #ccc;">TOTAL CK</td>
                                <?php $__currentLoopData = $filteredRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center;"><?php echo e($record->totalCairanKeluar()); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="border:1px solid #ccc; text-align:center;">
                                    <?php echo e($filteredRecords->sum(fn($r) => $r->totalCairanKeluar())); ?>

                                </td>
                            </tr>

                            
                            <tr style="font-weight:bold; color:#111;">
                                <td style="border:1px solid #ccc; background:#e0e7ff;">BALANCE</td>
                                <?php $__currentLoopData = $filteredRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $balance = $record->totalCairanMasuk() - $record->totalCairanKeluar();
                                $color = $balance < 0 ? '#fecaca' : '#e0e7ff' ; ?> <td style="border:1px solid #ccc; text-align:center; background:<?php echo e($color); ?>;"><?php echo e($balance); ?>

            </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php
            $totalBalance = $filteredRecords->sum(fn($r) => $r->totalCairanMasuk() - $r->totalCairanKeluar());
            $totalColor = $totalBalance < 0 ? '#fecaca' : '#e0e7ff' ; ?> <td style="border:1px solid #ccc; text-align:center; background:<?php echo e($totalColor); ?>;"><?php echo e($totalBalance); ?></td>
        </tr>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
    <?php
    // Ambil jam unik dari data obat
    $jamList = $medications->pluck('given_at')
    ->map(fn($t) => \Carbon\Carbon::parse($t)->format('H:i'))
    ->unique()
    ->sort()
    ->values();
    // Ambil nama obat unik
    $medNames = $medications->pluck('medication_name')->unique()->values();

    // Matriks data: [nama_obat][jam] = dosis/rute
    $matrix = [];
    foreach($medications as $med){
    $jam = \Carbon\Carbon::parse($med->given_at)->format('H:i');
    $matrix[$med->medication_name][$jam] = $med->dose . ' / ' . $med->route;
    }
    // Batas dosis untuk highlight (mg)
    $highlightThreshold = 500;
    ?>

    
    <?php if($medications->isNotEmpty()): ?>
    <div style="background:#f0f4ff; border-radius:8px; padding:6px; font-size:8px;">
        <h3 style="text-align: center; background-color: #dee2e6; padding: 4px; border-radius: 4px; font-size: 10px; margin-bottom: 4px;">
            Obat-Obatan
        </h3>
        <table style="width:100%; border-collapse:collapse; font-size:8px; margin-top:4px;">
            <thead>
                <tr style="background:#e0e7ff;">
                    <th style="border:1px solid #ccc; padding:2px 4px; text-align:left;">Obat</th>
                    <?php $__currentLoopData = $jamList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th style="border:1px solid #ccc; padding:2px 4px; text-align:center;"><?php echo e($jam); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $medNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border:1px solid #ccc; padding:2px 4px; font-weight:bold;"><?php echo e($medName); ?></td>
                    <?php $__currentLoopData = $jamList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $cell = $matrix[$medName][$jam] ?? '';
                    $highlight = '';
                    if($cell !== '' && preg_match('/\d+/', $cell, $m) && intval($m[0])>500) $highlight='color:red;font-weight:bold;';
                    ?>
                    <td style="border:1px solid #ccc; text-align:center; <?php echo e($highlight); ?>"><?php echo e($cell); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    </td>
    </tr>
    </table>



</body>
</html>
<?php /**PATH C:\Karitas\monitoring-rs\resources\views/pdf/monitoring-report.blade.php ENDPATH**/ ?>