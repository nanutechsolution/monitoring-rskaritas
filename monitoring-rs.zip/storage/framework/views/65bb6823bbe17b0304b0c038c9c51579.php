<div>
    <!-- Tombol buka modal -->
    <button type="button" wire:click="$set('showTherapyModal', true)" class="px-4 py-2 bg-primary-600 text-white rounded hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900">
        Program Terapi
    </button>

    <!-- Modal -->
    <!--[if BLOCK]><![endif]--><?php if($showTherapyModal): ?>
    <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900 bg-opacity-60 backdrop-blur-sm">
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] flex flex-col">

            <!-- Header -->
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <h2 class="text-xl font-semibold text-gray-800 dark:text-gray-100">
                    Program Terapi & Instruksi Dokter
                </h2>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Lihat riwayat di sebelah kiri, buat atau perbarui instruksi di sebelah kanan.
                </p>
            </div>

            <!-- Body -->
            <div class="flex-1 overflow-y-auto p-6">
                <div class="grid md:grid-cols-5 gap-6 h-full">

                    <!-- Riwayat Instruksi -->
                    <div class="md:col-span-2 max-h-[calc(80vh-150px)] overflow-y-auto pr-3 space-y-4">
                        <h3 class="text-lg font-medium text-gray-700 dark:text-gray-200 mb-2 sticky top-0 bg-white dark:bg-gray-800 py-2">
                            Riwayat Instruksi
                        </h3>

                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $therapy_program_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div wire:click="loadHistoryToForm(<?php echo e($program->id); ?>)" wire:loading.attr="disabled" class="border p-3 rounded-lg cursor-pointer transition hover:bg-gray-50 dark:hover:bg-gray-700
                            <?php if($loop->first): ?> border-primary-500 ring-2 ring-primary-100 dark:ring-primary-900 <?php else: ?> border-gray-200 dark:border-gray-600 <?php endif; ?>">
                            <div class="flex justify-between items-center text-sm mb-2 pb-2 border-b dark:border-gray-600">
                                <span class="font-semibold text-primary-700 dark:text-primary-300"><?php echo e($program->author_name); ?></span>
                                <span class="text-gray-500 dark:text-gray-400 text-xs"><?php echo e($program->created_at->format('d M Y, H:i')); ?></span>
                            </div>
                            <div class="text-sm text-gray-800 dark:text-gray-200 space-y-2">
                                <div>
                                    <strong class="text-gray-600 dark:text-gray-400 block text-xs">Masalah Klinis:</strong>
                                    <p class="pl-2"><?php echo e($program->masalah_klinis); ?></p>
                                </div>
                                <div>
                                    <strong class="text-gray-600 dark:text-gray-400 block text-xs">Program Terapi:</strong>
                                    <p class="pl-2"><?php echo e($program->program_terapi); ?></p>
                                </div>
                                <div>
                                    <strong class="text-gray-600 dark:text-gray-400 block text-xs">Enteral:</strong>
                                    <p class="pl-2"><?php echo e($program->nutrisi_enteral); ?></p>
                                </div>
                                <div>
                                    <strong class="text-gray-600 dark:text-gray-400 block text-xs">Parenteral:</strong>
                                    <p class="pl-2"><?php echo e($program->nutrisi_parenteral); ?></p>
                                </div>
                                <div>
                                    <strong class="text-gray-600 dark:text-gray-400 block text-xs">Lab:</strong>
                                    <p class="pl-2"><?php echo e($program->pemeriksaan_lab); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-gray-500 dark:text-gray-400 italic">Belum ada riwayat program terapi.</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Form Program Terapi -->
                    <div class="md:col-span-3 space-y-4">
                        <div class="flex justify-between items-center mb-2">
                            <h3 class="text-lg font-medium text-gray-700 dark:text-gray-200">Buat / Perbarui Instruksi</h3>
                            <button type="button" wire:click="resetForm" class="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-xs font-medium rounded border hover:bg-gray-200 dark:hover:bg-gray-600">
                                Reset / Tulis Baru
                            </button>
                        </div>

                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['currentCycleId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-sm text-red-600 dark:text-red-400 p-2 border rounded bg-red-50 dark:bg-red-900/50"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Masalah Klinis</label>
                                <textarea wire:model.defer="masalah" rows="3" class="w-full rounded border p-2 bg-white dark:bg-gray-700 dark:text-gray-100 border-gray-300 dark:border-gray-600"></textarea>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['masalah_klinis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Program Terapi</label>
                                <textarea wire:model.defer="program" rows="4" class="w-full rounded border p-2 bg-white dark:bg-gray-700 dark:text-gray-100 border-gray-300 dark:border-gray-600"></textarea>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['program_terapi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>

                            <div class="grid md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Enteral</label>
                                    <textarea wire:model.defer="enteral" rows="3" class="w-full rounded border p-2 bg-white dark:bg-gray-700 dark:text-gray-100 border-gray-300 dark:border-gray-600"></textarea>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nutrisi_enteral'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Parenteral</label>
                                    <textarea wire:model.defer="parenteral" rows="3" class="w-full rounded border p-2 bg-white dark:bg-gray-700 dark:text-gray-100 border-gray-300 dark:border-gray-600"></textarea>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nutrisi_parenteral'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Lab</label>
                                <textarea wire:model.defer="lab" rows="3" class="w-full rounded border p-2 bg-white dark:bg-gray-700 dark:text-gray-100 border-gray-300 dark:border-gray-600"></textarea>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['pemeriksaan_lab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Footer -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t flex justify-end space-x-3">
                <button type="button" wire:click="$set('showTherapyModal', false)" class="px-4 py-2 bg-white dark:bg-gray-700 rounded border hover:bg-gray-100 dark:hover:bg-gray-600">
                    Batal
                </button>
                <button type="button" wire:click="save" wire:loading.attr="disabled" class="px-4 py-2 bg-primary-600 text-white rounded hover:bg-primary-700">
                    <span wire:loading.remove wire:target="save">Simpan</span>
                    <span wire:loading wire:target="save">Menyimpan...</span>
                </button>

            </div>

        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Karitas\monitoring-rs\resources\views/livewire/therapy-program-modal.blade.php ENDPATH**/ ?>