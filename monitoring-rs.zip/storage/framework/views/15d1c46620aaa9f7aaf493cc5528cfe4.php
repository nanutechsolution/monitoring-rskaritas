<?php
use Carbon\Carbon;

// --- Logika PHP Anda (Sudah Benar) ---
$allInfusNames = collect();
foreach ($fluidRecords as $record) {
    $allInfusNames = $allInfusNames->merge($record->parenteralIntakes->pluck('name'));
}
$uniqueInfusNames = $allInfusNames->unique()->values();

$allEnteralNames = collect();
foreach ($fluidRecords as $record) {
    $allEnteralNames = $allEnteralNames->merge($record->enteralIntakes->pluck('name'));
}
$uniqueEnteralNames = $allEnteralNames->unique()->values();

// === KELAS HELPER UNTUK TEMA ===
$headerBg = 'bg-gray-100 dark:bg-gray-700';
$headerText = 'text-gray-700 dark:text-gray-300';
$headerStickyBg = 'bg-gray-100 dark:bg-gray-700';

$rowBg = 'bg-white dark:bg-gray-800';
$rowBgAlt = 'bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50';
$rowStickyBg = 'bg-white dark:bg-gray-800';

// Hover colors
$rowHoverPrimary = 'hover:bg-primary-50 dark:hover:bg-gray-700';
$rowHoverDanger = 'hover:bg-danger-50 dark:hover:bg-gray-700';

// Total row colors
$rowTotalCmBg = 'bg-green-100 dark:bg-green-900 dark:bg-opacity-30';
$rowTotalCmText = 'text-green-800 dark:text-green-200';

$rowTotalCkBg = 'bg-danger-100 dark:bg-danger-900 dark:bg-opacity-30';
$rowTotalCkText = 'text-danger-800 dark:text-danger-200';

// Balance row colors
$rowBalanceBg = 'bg-primary-600 dark:bg-primary-700';
$rowBalanceText = 'text-white';
$balancePositiveBg = 'bg-primary-50 dark:bg-primary-900 dark:bg-opacity-50';
$balancePositiveText = 'text-primary-700 dark:text-primary-200';
$balanceNegativeBg = 'bg-danger-600 dark:bg-danger-700';
$balanceNegativeText = 'text-white';

$border = 'border dark:border-gray-600';

?>

<div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg border border-gray-100 dark:border-gray-700 p-4 sm:p-6">
    <div class="overflow-x-auto relative max-h-[80vh]">
        <h5 class="text-sm font-bold text-gray-700 dark:text-gray-200 mb-3 uppercase tracking-wide">
            💧 Keseimbangan Cairan per Jam
        </h5>

        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400 border-collapse">

            
            <thead class="text-xs <?php echo e($headerText); ?> uppercase <?php echo e($headerBg); ?> sticky top-0 z-10">
                <tr>
                    <th scope="col" class="sticky left-0 <?php echo e($headerStickyBg); ?> <?php echo e($border); ?> px-2 py-1 text-left w-48 z-20">Jenis Cairan</th>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fluidRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="<?php echo e($border); ?> px-2 py-1 text-center">
                        <?php echo e(date('H:i', strtotime($record->record_time))); ?>

                        <div class="text-[10px] text-gray-500 dark:text-gray-400 italic mt-0.5">
                            oleh <?php echo e($record->author_name ?? '-'); ?>

                        </div>
                    </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <th class="<?php echo e($border); ?> px-2 py-1 text-center bg-gray-50 dark:bg-gray-600">TOTAL</th>
                </tr>
            </thead>

            <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                
                <tr class="<?php echo e($rowBgAlt); ?> font-semibold">
                    <td colspan="<?php echo e(count($fluidRecords) + 2); ?>" class="px-2 py-1 text-gray-700 dark:text-gray-200">
                        Parenteral (Infus)
                    </td>
                </tr>

                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $uniqueInfusNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infusName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="<?php echo e($rowBg); ?> <?php echo e($rowHoverPrimary); ?> transition-colors duration-100">
                    <td class="sticky left-0 <?php echo e($rowStickyBg); ?> <?php echo e($border); ?> px-2 py-1 text-gray-700 dark:text-gray-300 italic z-10" style="padding-left: 25px;"><?php echo e($infusName); ?></td>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fluidRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $infus = $record->parenteralIntakes->firstWhere('name', $infusName);
                    ?>
                    <td class="<?php echo e($border); ?> text-center">
                        <!--[if BLOCK]><![endif]--><?php if($infus && $infus->volume > 0): ?>
                            <span class="font-semibold text-green-600 dark:text-green-400"><?php echo e($infus->volume); ?></span>
                        <?php else: ?>
                            <span class="text-gray-300 dark:text-gray-600">-</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <td class="<?php echo e($border); ?> text-center font-semibold <?php echo e($rowBgAlt); ?> dark:bg-gray-700">
                        <?php echo e($fluidRecords->sum(fn($r) => ($r->parenteralIntakes->firstWhere('name', $infusName)?->volume ?? 0))); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr class="<?php echo e($rowBg); ?>">
                    <td class="sticky left-0 <?php echo e($rowStickyBg); ?> px-4 py-1 italic text-gray-400 dark:text-gray-500 z-10" style="padding-left: 25px;">- Tidak ada input parenteral -</td>
                    <td colspan="<?php echo e(count($fluidRecords) + 1); ?>"></td>
                </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                
                <tr class="<?php echo e($rowBgAlt); ?> font-semibold">
                    <td colspan="<?php echo e(count($fluidRecords) + 2); ?>" class="px-2 py-1 text-gray-700 dark:text-gray-200">
                        Enteral
                    </td>
                </tr>

                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $uniqueEnteralNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enteralName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="<?php echo e($rowBg); ?> <?php echo e($rowHoverPrimary); ?>">
                    <td class="sticky left-0 <?php echo e($rowStickyBg); ?> <?php echo e($border); ?> px-2 py-1 text-gray-700 dark:text-gray-300 italic z-10" style="padding-left: 25px;"><?php echo e($enteralName); ?></td>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fluidRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $enteral = $record->enteralIntakes->firstWhere('name', $enteralName);
                    ?>
                    <td class="<?php echo e($border); ?> text-center">
                        <!--[if BLOCK]><![endif]--><?php if($enteral && $enteral->volume > 0): ?>
                            <span class="font-semibold text-green-600 dark:text-green-400"><?php echo e($enteral->volume); ?></span>
                        <?php else: ?>
                            <span class="text-gray-300 dark:text-gray-600">-</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <td class="<?php echo e($border); ?> text-center font-semibold <?php echo e($rowBgAlt); ?> dark:bg-gray-700">
                        <?php echo e($fluidRecords->sum(fn($r) => ($r->enteralIntakes->firstWhere('name', $enteralName)?->volume ?? 0))); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <tr class="<?php echo e($rowBg); ?>">
                    <td class="sticky left-0 <?php echo e($rowStickyBg); ?> px-4 py-1 italic text-gray-400 dark:text-gray-500 z-10" style="padding-left: 25px;">- Tidak ada input enteral -</td>
                    <td colspan="<?php echo e(count($fluidRecords) + 1); ?>"></td>
                </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                
                <tr class="<?php echo e($rowBg); ?> <?php echo e($rowHoverPrimary); ?>">
                    <td class="sticky left-0 <?php echo e($rowStickyBg); ?> <?php echo e($border); ?> px-2 py-1 text-gray-700 dark:text-gray-300 z-10">OGT</td>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fluidRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td class="<?php echo e($border); ?> text-center"><?php echo e($record->intake_ogt ?: '-'); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <td class="<?php echo e($border); ?> text-center font-semibold <?php echo e($rowBgAlt); ?> dark:bg-gray-700"><?php echo e($fluidRecords->sum('intake_ogt')); ?></td>
                </tr>

                
                <tr class="<?php echo e($rowBg); ?> <?php echo e($rowHoverPrimary); ?>">
                    <td class="sticky left-0 <?php echo e($rowStickyBg); ?> <?php echo e($border); ?> px-2 py-1 text-gray-700 dark:text-gray-300 z-10">Oral</td>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fluidRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td class="<?php echo e($border); ?> text-center"><?php echo e($record->intake_oral ?: '-'); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <td class="<?php echo e($border); ?> text-center font-semibold <?php echo e($rowBgAlt); ?> dark:bg-gray-700"><?php echo e($fluidRecords->sum('intake_oral')); ?></td>
                </tr>

                
                <tr class="<?php echo e($rowTotalCmBg); ?> font-bold">
                    <td class="sticky left-0 <?php echo e($rowTotalCmBg); ?> <?php echo e($border); ?> dark:border-green-800 px-2 py-1 <?php echo e($rowTotalCmText); ?> z-10">TOTAL CM</td>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fluidRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td class="<?php echo e($border); ?> dark:border-gray-600 text-center <?php echo e($rowTotalCmText); ?>"><?php echo e($record->totalCairanMasuk()); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <td class="<?php echo e($border); ?> dark:border-gray-600 text-center font-semibold <?php echo e($rowTotalCmText); ?>"><?php echo e($fluidRecords->sum(fn($r) => $r->totalCairanMasuk())); ?></td>
                </tr>

                
                <tr class="<?php echo e($rowBgAlt); ?> font-semibold">
                    <td colspan="<?php echo e(count($fluidRecords) + 2); ?>" class="px-2 py-1 text-gray-700 dark:text-gray-200">OUTPUT (Cairan Keluar)</td>
                </tr>

                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = ['output_ngt' => 'NGT','output_urine' => 'Urine','output_bab' => 'BAB','output_drain' => 'Drain']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="<?php echo e($rowBg); ?> <?php echo e($rowHoverDanger); ?>">
                    <td class="sticky left-0 <?php echo e($rowStickyBg); ?> <?php echo e($border); ?> px-2 py-1 text-gray-700 dark:text-gray-300 z-10"><?php echo e($label); ?></td>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fluidRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td class="<?php echo e($border); ?> dark:border-gray-600 text-center">
                        <!--[if BLOCK]><![endif]--><?php if($record->$field > 0): ?>
                            <span class="font-semibold text-danger-600 dark:text-danger-400"><?php echo e($record->$field); ?></span>
                        <?php else: ?>
                            <span class="text-gray-300 dark:text-gray-600">-</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <td class="<?php echo e($border); ?> dark:border-gray-600 text-center font-semibold <?php echo e($rowBgAlt); ?> dark:bg-gray-700"><?php echo e($fluidRecords->sum($field)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                
                <tr class="<?php echo e($rowTotalCkBg); ?> font-bold">
                    <td class="sticky left-0 <?php echo e($rowTotalCkBg); ?> <?php echo e($border); ?> dark:border-danger-700 px-2 py-1 <?php echo e($rowTotalCkText); ?> z-10">TOTAL CK</td>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fluidRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td class="<?php echo e($border); ?> dark:border-gray-600 text-center <?php echo e($rowTotalCkText); ?>"><?php echo e($record->totalCairanKeluar()); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <td class="<?php echo e($border); ?> dark:border-gray-600 text-center font-semibold <?php echo e($rowTotalCkText); ?>"><?php echo e($fluidRecords->sum(fn($r) => $r->totalCairanKeluar())); ?></td>
                </tr>

                
                <tr class="font-bold">
                    <td class="sticky left-0 <?php echo e($rowBalanceBg); ?> <?php echo e($border); ?> dark:border-primary-600 px-2 py-1 <?php echo e($rowBalanceText); ?> z-10">BALANCE</td>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fluidRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $balance = $record->totalCairanMasuk() - $record->totalCairanKeluar();
                            $bgColor = $balance < 0 ? ($balanceNegativeBg.' '.$balanceNegativeText) : ($balancePositiveBg.' '.$balancePositiveText);
                        ?>
                    <td class="<?php echo e($border); ?> dark:border-gray-600 text-center <?php echo e($bgColor); ?>"><?php echo e($balance); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php
                        $totalBalance = $fluidRecords->sum(fn($r) => $r->totalCairanMasuk() - $r->totalCairanKeluar());
                        $totalBgColor = $totalBalance < 0 ? ($balanceNegativeBg.' '.$balanceNegativeText) : 'bg-primary-100 dark:bg-primary-800 text-primary-800 dark:text-primary-100 font-semibold' ;
                    ?>
                    <td class="<?php echo e($border); ?> dark:border-gray-600 text-center <?php echo e($totalBgColor); ?>"><?php echo e($totalBalance); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!--[if BLOCK]><![endif]--><?php if($fluidRecords->isEmpty()): ?>
        <p class="text-gray-500 dark:text-gray-400 text-center py-10">Belum ada data cairan masuk/keluar untuk siklus ini.</p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Karitas\monitoring-rs\resources\views/livewire/patient-monitor/partials/output-tabel-cairan.blade.php ENDPATH**/ ?>