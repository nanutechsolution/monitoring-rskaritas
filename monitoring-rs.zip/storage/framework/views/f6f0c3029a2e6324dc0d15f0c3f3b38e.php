<div class="relative">
    
    <input type="text" class="w-full text-sm rounded-md border-gray-300 shadow-sm" placeholder="Ketik nama obat..." wire:model.live.debounce.300ms="query" wire:keydown.escape="isOpen = false" wire:focus="triggerSearch">

    
    <!--[if BLOCK]><![endif]--><?php if($isOpen && count($results) > 0): ?>
    <div class="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg">
        <ul class="max-h-60 overflow-y-auto">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-100" wire:click.prevent="selectDrug('<?php echo e($result->nm_obat); ?>')">
                    <?php echo e($result->nm_obat); ?>

                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    </div>
    
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Karitas\monitoring-rs\resources\views/livewire/drug-search-autocomplete.blade.php ENDPATH**/ ?>