<div class="space-y-6 animate-pulse">
    
    <div class="bg-white dark:bg-gray-800 shadow-sm rounded-lg overflow-hidden border border-gray-100 dark:border-gray-700 p-4">

        
        <div class="h-5 bg-gray-200 dark:bg-gray-700 rounded w-1/4 mb-4"></div>

        
        <div class="overflow-x-auto">
            <table class="min-w-full">
                
                <thead class="bg-gray-100 dark:bg-gray-700">
                    <tr>
                        <th class="px-2 py-3 text-left">
                            <div class="h-4 bg-gray-300 dark:bg-gray-600 rounded w-20"></div>
                        </th>
                        <th class="px-2 py-3">
                            <div class="h-4 bg-gray-300 dark:bg-gray-600 rounded w-16 mx-auto"></div>
                        </th>
                        <th class="px-2 py-3">
                            <div class="h-4 bg-gray-300 dark:bg-gray-600 rounded w-16 mx-auto"></div>
                        </th>
                    </tr>
                </thead>
                
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = range(1, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e($loop->even ? 'bg-gray-50 dark:bg-gray-700' : 'bg-white dark:bg-gray-800'); ?>">
                        <td class="px-2 py-3 border-t dark:border-gray-700">
                            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-24"></div>
                        </td>
                        <td class="px-2 py-3 border-t dark:border-gray-700">
                            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-12 mx-auto"></div>
                        </td>
                        <td class="px-2 py-3 border-t dark:border-gray-700">
                            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-12 mx-auto"></div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\Karitas\monitoring-rs\resources\views/livewire/placeholders/ventilator-table-skeleton.blade.php ENDPATH**/ ?>