<div class="space-y-6">
    <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg border border-gray-100 dark:border-gray-700 overflow-hidden animate-pulse">
        <div class="p-6">
            <div class="h-5 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-3 pb-3"></div>
            <div class="mt-4 space-y-2">
                <div class="h-8 bg-gray-100 dark:bg-gray-700 rounded w-full"></div>
                <div class="h-8 bg-gray-200 dark:bg-gray-600 rounded w-full"></div>
            </div>
        </div>
    </div>
    <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg border border-gray-100 dark:border-gray-700 overflow-hidden animate-pulse">
        <div class="p-6">
            <div class="h-5 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-3 pb-3"></div>
            <div class="mt-4 grid grid-cols-3 gap-6">
                <div class="h-24 bg-gray-100 dark:bg-gray-700 rounded w-full"></div>
                <div class="h-24 bg-gray-200 dark:bg-gray-600 rounded w-full"></div>
                <div class="h-24 bg-gray-100 dark:bg-gray-700 rounded w-full"></div>
            </div>
        </div>
    </div>
</div>