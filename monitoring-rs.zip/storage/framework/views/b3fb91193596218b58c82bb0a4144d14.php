<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['records', 'title' => 'Data Ventilator & Monitor']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['records', 'title' => 'Data Ventilator & Monitor']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
use Carbon\Carbon;

$sections = [
    'Spontan' => [
        'spontan_fio2' => 'FiO2',
        'spontan_flow' => 'Flow'
    ],
    'CPAP' => [
        'cpap_fio2' => 'FiO2',
        'cpap_flow' => 'Flow',
        'cpap_peep' => 'PEEP',
    ],
    'HFO' => [
        'hfo_fio2' => 'FiO2',
        'hfo_frekuensi' => 'Frekuensi',
        'hfo_map' => 'MAP',
        'hfo_amplitudo' => 'Amplitudo',
        'hfo_it' => 'I:T',
    ],
    'Monitor' => [
        'monitor_mode' => 'Mode',
        'monitor_fio2' => 'FiO2',
        'monitor_peep' => 'PEEP',
        'monitor_pip' => 'PIP',
        'monitor_tv_vte' => 'TV/VTE',
        'monitor_rr_spontan' => 'RR Spontan',
        'monitor_p_max' => 'P Max',
        'monitor_ie' => 'I:E',
    ],
];

$userInfoMap = [];
foreach ($records as $r) {
    $jam = Carbon::parse($r->record_time)->format('H:i');
    $userInfoMap[$jam] = [
        'nama' => $r->author_name,
        'nik' => $r->pegawai->nik ?? '-',
        'recorded_at' => Carbon::parse($r->record_time)->format('d/m H:i'),
    ];
}

// --- Kelas Helper untuk Tema ---
$headerBg = 'bg-gray-100 dark:bg-gray-700';
$headerText = 'text-gray-700 dark:text-gray-300';
$headerStickyBg = 'bg-gray-100 dark:bg-gray-700';

$rowBg = 'bg-white dark:bg-gray-800';
$rowBgAlt = 'bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50';
$rowStickyBg = 'bg-white dark:bg-gray-800';
$rowStickyBgAlt = 'bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50';
$rowHover = 'hover:bg-primary-50 dark:hover:bg-gray-600 dark:hover:bg-opacity-50';

$border = 'border dark:border-gray-600';
?>

<div class="space-y-6">
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectionTitle => $columns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $sectionRecords = $records->filter(function($record) use ($columns) {
                foreach($columns as $field => $label) {
                    if(!empty($record->$field)) return true;
                }
                return false;
            });

            if($sectionRecords->isEmpty()) continue;

            $jamList = $sectionRecords->map(fn($r) => Carbon::parse($r->record_time)->format('H:i'))
                ->unique()
                ->sort()
                ->values();
        ?>

        <div class="bg-white dark:bg-gray-800 shadow-sm rounded-lg overflow-hidden border border-gray-100 dark:border-gray-700 p-4">
            <h4 class="text-md font-semibold mb-3 text-primary-700 dark:text-primary-300"><?php echo e($sectionTitle); ?></h4>

            <div class="overflow-x-auto">
                <table class="min-w-max <?php echo e($border); ?> border-gray-200 text-sm">
                    <thead class="<?php echo e($headerBg); ?> sticky top-0 z-10 <?php echo e($headerText); ?>">
                        <tr>
                            <th class="<?php echo e($border); ?> px-2 py-1 text-left sticky left-0 <?php echo e($headerStickyBg); ?> z-10">Parameter</th>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $jamList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $u = $userInfoMap[$jam] ?? null; ?>
                                <th class="<?php echo e($border); ?> px-2 py-1 text-center relative group">
                                    <div class="flex flex-col items-center">
                                        <span><?php echo e($jam); ?></span>
                                        <span class="text-[11px] text-gray-600 dark:text-gray-400 font-medium"><?php echo e($u['nama'] ?? '-'); ?></span>
                                    </div>
                                    <!--[if BLOCK]><![endif]--><?php if($u): ?>
                                    <div class="absolute hidden group-hover:block
                                                bg-gray-800 dark:bg-gray-900 text-white
                                                text-xs rounded-lg px-2 py-1 shadow-md
                                                -translate-x-1/2 left-1/2 mt-1 z-20">
                                        <div><b><?php echo e($u['nama']); ?></b></div>
                                        <div>NIK: <?php echo e($u['nik']); ?></div>
                                        <div>Input: <?php echo e($u['recorded_at']); ?></div>
                                    </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    </thead>
                    <tbody class="text-gray-700 dark:text-gray-300">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($loop->even ? $rowBgAlt : $rowBg); ?> <?php echo e($rowHover); ?>">
                                <td class="<?php echo e($border); ?> px-2 py-1 font-medium sticky left-0 z-10
                                           <?php echo e($loop->even ? $rowStickyBgAlt : $rowStickyBg); ?>

                                           text-gray-900 dark:text-gray-100">
                                    <?php echo e($label); ?>

                                </td>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $jamList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $record = $sectionRecords->first(fn($r) => Carbon::parse($r->record_time)->format('H:i') === $jam);
                                        $value = $record->$field ?? '-';
                                        $highlight = '';
                                        if(is_numeric($value)) {
                                            // DIUBAH: Menggunakan 'danger' untuk highlight
                                            if(in_array($field, ['spontan_fio2','cpap_fio2','hfo_fio2','monitor_fio2']) && $value > 60) $highlight = 'text-danger-600 dark:text-danger-400 font-semibold';
                                            if(in_array($field, ['cpap_peep','monitor_peep']) && $value > 8) $highlight = 'text-danger-600 dark:text-danger-400 font-semibold';
                                            if($field == 'monitor_rr_spontan' && ($value < 30 || $value > 60)) $highlight = 'text-danger-600 dark:text-danger-400 font-semibold';
                                        }
                                    ?>
                                    <td class="<?php echo e($border); ?> px-2 py-1 text-center <?php echo e($highlight); ?>"><?php echo e($value); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($records->isEmpty()): ?>
        <div class="text-gray-500 dark:text-gray-400 text-center">Belum ada data ventilator</div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Karitas\monitoring-rs\resources\views/livewire/patient-monitor/partials/output-tabel-ventilator.blade.php ENDPATH**/ ?>