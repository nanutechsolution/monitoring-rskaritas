    <div class="lg:col-span-1 space-y-6">
        <div class="overflow-x-auto py-3 -mx-3 scroll-smooth scrollbar-thin ...">
            <div class="flex gap-3 px-3 min-w-max snap-x snap-mandatory">
                <!--[if BLOCK]><![endif]--><?php if($currentCycleId): ?>
                <?php echo $__env->make('livewire.patient-monitor.partials.modal-kejadian-cepat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('livewire.patient-monitor.partials.modal-gasdarah', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('therapy-program-modal', ['currentCycleId' => $currentCycleId,'noRawat' => $no_rawat]);

$__html = app('livewire')->mount($__name, $__params, '\'therapy-modal-\'.$currentCycleId', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
        <form wire:submit="saveRecord" class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 text-gray-900 dark:text-gray-100">
                <div class="mt-4">
                    <h3 class="text-lg font-medium border-b dark:border-gray-700 pb-3">Form Input Observasi</h3>
                    <div x-data="{
        currentTime: new Date(<?php echo json_encode(now()->timestamp * 1000, 15, 512) ?>)
    }" x-init="setInterval(() => currentTime = new Date(currentTime.getTime() + 1000), 1000)" class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tanggal & Jam Observasi</label>
                        <div class="mt-1 block w-full rounded-md border border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-700 shadow-sm px-3 py-2 sm:text-sm text-gray-700 dark:text-gray-300">
                            <span x-text="currentTime.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })"></span>
                            <span> - </span>
                            <span x-text="currentTime.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' })"></span>
                        </div>
                    </div>

                </div>
                <div class="border-b border-gray-200 dark:border-gray-700 mt-4">
                    <nav class="bg-gray-50 dark:bg-gray-900 shadow-sm -mb-px flex space-x-2 sm:space-x-4 overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600 scrollbar-track-gray-100 dark:scrollbar-track-gray-800 px-2 py-1" aria-label="Tabs">
                        <button wire:click.prevent="$set('activeTab', 'observasi')" type="button" class="<?php echo e($activeTab === 'observasi' ? 'border-primary-500 text-primary-600 bg-white dark:bg-gray-800 dark:text-primary-400' : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:border-gray-300 dark:hover:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700'); ?> whitespace-nowrap py-2 px-3 border-b-2 font-medium text-sm rounded-t-md transition-colors">
                            Observasi
                        </button>
                        <button wire:click.prevent="$set('activeTab', 'ventilator')" type="button" class="<?php echo e($activeTab === 'ventilator' ? 'border-primary-500 text-primary-600 bg-white dark:bg-gray-800 dark:text-primary-400' : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:border-gray-300 dark:hover:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700'); ?> whitespace-nowrap py-2 px-3 border-b-2 font-medium text-sm rounded-t-md transition-colors">
                            Ventilator
                        </button>
                        <button wire:click.prevent="$set('activeTab', 'cairan')" type="button" class="<?php echo e($activeTab === 'cairan' ? 'border-primary-500 text-primary-600 bg-white dark:bg-gray-800 dark:text-primary-400' : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:border-gray-300 dark:hover:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700'); ?> whitespace-nowrap py-2 px-3 border-b-2 font-medium text-sm rounded-t-md transition-colors">
                            Cairan
                        </button>
                    </nav>
                </div>
                <div class="space-y-4 mt-4">
                    <!--[if BLOCK]><![endif]--><?php if($activeTab == 'observasi'): ?>
                    <?php echo $__env->make('livewire.patient-monitor.partials.tab-input-observasi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($activeTab == 'ventilator'): ?>
                    <div x-data="{ mode: null }" x-init="
        mode = $wire.respiratory_mode || 'monitor';
        $watch('mode', value => $wire.respiratory_mode = value)
    " class="space-y-4">
                        <?php
                        $labelClasses = 'block text-sm font-medium text-gray-700 dark:text-gray-300';
                        $selectClasses = 'mt-1 block w-full rounded-md shadow-sm sm:text-sm border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 focus:border-primary-500 focus:ring-primary-500';
                        $inputClasses = 'mt-1 w-full rounded-md shadow-sm text-sm border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-200 focus:border-primary-500 focus:ring-primary-500';
                        $cardClasses = 'space-y-2 p-3 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600';
                        $cardTitleClasses = 'text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wide';
                        ?>

                        <div class="space-y-3">
                            <div>
                                <label for="respiratory_mode" class="<?php echo e($labelClasses); ?>">Mode Pernapasan</label>
                                <select id="respiratory_mode" x-model="mode" class="<?php echo e($selectClasses); ?>">
                                    <option value="">Pilih Mode...</option>
                                    <option value="spontan">Spontan (Nasal)</option>
                                    <option value="cpap">CPAP</option>
                                    <option value="hfo">HFO</option>
                                    <option value="monitor">Ventilator Konvensional</option>
                                </select>
                            </div>

                            <!-- Spontan -->
                            <div x-show="mode === 'spontan'" x-transition>
                                <div class="<?php echo e($cardClasses); ?>">
                                    <h5 class="<?php echo e($cardTitleClasses); ?>">Setting Spontan</h5>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <label class="<?php echo e($labelClasses); ?>">FiO₂ (%)</label>
                                            <input type="text" wire:model.defer="spontan_fio2" class="<?php echo e($inputClasses); ?>">
                                        </div>
                                        <div>
                                            <label class="<?php echo e($labelClasses); ?>">Flow (Lpm)</label>
                                            <input type="text" wire:model.defer="spontan_flow" class="<?php echo e($inputClasses); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- CPAP -->
                            <div x-show="mode === 'cpap'" x-transition>
                                <div class="<?php echo e($cardClasses); ?>">
                                    <h5 class="<?php echo e($cardTitleClasses); ?>">Setting CPAP</h5>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <label class="<?php echo e($labelClasses); ?>">FiO₂ (%)</label>
                                            <input type="text" wire:model.defer="cpap_fio2" class="<?php echo e($inputClasses); ?>">
                                        </div>
                                        <div>
                                            <label class="<?php echo e($labelClasses); ?>">Flow (Lpm)</label>
                                            <input type="text" wire:model.defer="cpap_flow" class="<?php echo e($inputClasses); ?>">
                                        </div>
                                        <div>
                                            <label class="<?php echo e($labelClasses); ?>">PEEP (cmH₂O)</label>
                                            <input type="text" wire:model.defer="cpap_peep" class="<?php echo e($inputClasses); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- HFO -->
                            <div x-show="mode === 'hfo'" x-transition>
                                <div class="<?php echo e($cardClasses); ?>">
                                    <h5 class="<?php echo e($cardTitleClasses); ?>">Setting HFO</h5>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <label class="<?php echo e($labelClasses); ?>">FiO₂ (%)</label>
                                            <input type="text" wire:model.defer="hfo_fio2" class="<?php echo e($inputClasses); ?>">
                                        </div>
                                        <div>
                                            <label class="<?php echo e($labelClasses); ?>">Frekuensi (Hz)</label>
                                            <input type="text" wire:model.defer="hfo_frekuensi" class="<?php echo e($inputClasses); ?>">
                                        </div>
                                        <div>
                                            <label class="<?php echo e($labelClasses); ?>">MAP (cmH₂O)</label>
                                            <input type="text" wire:model.defer="hfo_map" class="<?php echo e($inputClasses); ?>">
                                        </div>
                                        <div>
                                            <label class="<?php echo e($labelClasses); ?>">Amplitudo (ΔP)</label>
                                            <input type="text" wire:model.defer="hfo_amplitudo" class="<?php echo e($inputClasses); ?>">
                                        </div>
                                        <div>
                                            <label class="<?php echo e($labelClasses); ?>">IT (%)</label>
                                            <input type="text" wire:model.defer="hfo_it" class="<?php echo e($inputClasses); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Ventilator Konvensional -->
                            <div x-show="mode === 'monitor'" x-transition>
                                <div class="<?php echo e($cardClasses); ?> p-4">
                                    <h5 class="<?php echo e($cardTitleClasses); ?>">Setting Ventilator</h5>
                                    <div class="grid grid-cols-2 gap-4 items-start">
                                        <div class="flex flex-col">
                                            <label class="<?php echo e($labelClasses); ?>">Mode</label>
                                            <input type="text" wire:model.defer="monitor_mode" class="<?php echo e($inputClasses); ?> h-9">
                                        </div>
                                        <div class="flex flex-col">
                                            <label class="<?php echo e($labelClasses); ?>">FiO₂ (%)</label>
                                            <input type="text" wire:model.defer="monitor_fio2" class="<?php echo e($inputClasses); ?> h-9">
                                        </div>
                                        <div class="flex flex-col">
                                            <label class="<?php echo e($labelClasses); ?>">PEEP (cmH₂O)</label>
                                            <input type="text" wire:model.defer="monitor_peep" class="<?php echo e($inputClasses); ?> h-9">
                                        </div>
                                        <div class="flex flex-col">
                                            <label class="<?php echo e($labelClasses); ?>">PIP (cmH₂O)</label>
                                            <input type="text" wire:model.defer="monitor_pip" class="<?php echo e($inputClasses); ?> h-9">
                                        </div>
                                        <div class="flex flex-col">
                                            <label class="<?php echo e($labelClasses); ?>">TV/Vte (ml)</label>
                                            <input type="text" wire:model.defer="monitor_tv_vte" class="<?php echo e($inputClasses); ?> h-9">
                                        </div>
                                        <div class="flex flex-col">
                                            <label class="<?php echo e($labelClasses); ?>">RR / RR Spontan</label>
                                            <input type="text" wire:model.defer="monitor_rr_spontan" class="<?php echo e($inputClasses); ?> h-9">
                                        </div>
                                        <div class="flex flex-col">
                                            <label class="<?php echo e($labelClasses); ?>">P.Max (cmH₂O)</label>
                                            <input type="text" wire:model.defer="monitor_p_max" class="<?php echo e($inputClasses); ?> h-9">
                                        </div>
                                        <div class="flex flex-col">
                                            <label class="<?php echo e($labelClasses); ?>">I : E</label>
                                            <input type="text" wire:model.defer="monitor_ie" class="<?php echo e($inputClasses); ?> h-9">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($activeTab == 'cairan'): ?>
                    <div class="space-y-4">
                        <?php echo $__env->make('livewire.patient-monitor.partials.tab-input-cairan-nicu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
            <div class="bg-gray-50 dark:bg-gray-700 px-4 py-3 space-y-3 border-t dark:border-gray-600">
                <div class="text-right">
                    <button type<?php echo e("="); ?> "submit" wire:loading.attr="disabled" @click="$dispatch('sync-repeaters')" <?php if($isReadOnly): echo 'disabled'; endif; ?> class="inline-flex justify-center rounded-md border border-transparent
                       bg-primary-600 py-2 px-4 text-sm font-medium text-white shadow-sm
                       hover:bg-primary-700
                       focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2
                       dark:focus:ring-offset-gray-800
                       disabled:opacity-50 disabled:cursor-not-allowed">
                        <span wire:loading.remove wire:target="saveRecord">Simpan Catatan</span>
                        <span wire:loading wire:target="saveRecord">Menyimpan...</span>
                    </button>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['record'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-sm mt-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['record_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-sm mt-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </form>
    </div>
<?php /**PATH C:\Karitas\monitoring-rs\resources\views/livewire/patient-monitor/nicu-input-form.blade.php ENDPATH**/ ?>