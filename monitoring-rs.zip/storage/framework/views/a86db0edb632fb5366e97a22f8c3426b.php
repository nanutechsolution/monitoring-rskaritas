<div x-data="{
         showBloodGasModal: false,
         taken_at: '<?php echo e(now()->format('Y-m-d\TH:i')); ?>',
         gula_darah: null,
         ph: null,
         pco2: null,
         po2: null,
         hco3: null,
         be: null,
         sao2: null,
         resetForm() {
             this.taken_at = '<?php echo e(now()->format('Y-m-d\TH:i')); ?>';
             this.gula_darah = null; this.ph = null; this.pco2 = null;
             this.po2 = null; this.hco3 = null; this.be = null; this.sao2 = null;
         }
     }">

    
    <button type="button" @click="showBloodGasModal = true; resetForm()"
            class="flex items-center gap-2 px-5 py-2
                   bg-white dark:bg-gray-800
                   border dark:border-gray-700 rounded-lg shadow
                   hover:shadow-md hover:bg-danger-50 dark:hover:bg-gray-700
                   flex-shrink-0 snap-start transition-all">
        <svg class="w-5 h-5 text-danger-600 dark:text-danger-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6"></path>
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v6"></path>
        </svg>
        <span class="font-medium text-gray-800 dark:text-gray-100">Gas Darah</span>
    </button>

    
    <div x-show="showBloodGasModal"
         x-cloak
         x-transition:enter="ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900 bg-opacity-60 backdrop-blur-sm"
         @keydown.escape.window="showBloodGasModal = false">

        <div x-show="showBloodGasModal"
             @click.away="showBloodGasModal = false; resetForm()"
             x-transition:enter="ease-out duration-300"
             x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
             x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
             x-transition:leave="ease-in duration-200"
             x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
             x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
             class="relative w-full max-w-3xl bg-white dark:bg-gray-800 rounded-lg shadow-xl flex flex-col max-h-[90vh] overflow-hidden">

            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700">
                <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100 flex items-center gap-2">
                    <svg class="w-6 h-6 text-danger-600 dark:text-danger-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-3-3v6m-6 3h12a2 2 0 002-2V8a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                    Catat Hasil Analisis Gas Darah (AGD)
                </h3>
                <button @click="showBloodGasModal = false; resetForm()" class="text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>

            <?php
                // --- Kelas Helper untuk Konsistensi ---
                $inputModalClasses = 'mt-1 block w-full rounded-md shadow-sm sm:text-sm
                                     border-gray-300 dark:border-gray-600
                                     bg-white dark:bg-gray-700
                                     text-gray-900 dark:text-gray-200
                                     focus:border-primary-500 focus:ring-primary-500
                                     appearance-none [-moz-appearance:textfield] [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:m-0 [&::-webkit-outer-spin-button]:appearance-none';
                $labelModalClasses = 'block text-sm font-medium text-gray-700 dark:text-gray-300';
                $errorModalClasses = 'text-xs text-danger-600 dark:text-danger-400 mt-1';
            ?>

            <div class="px-6 py-5 overflow-y-auto">
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-x-5 gap-y-6">
                    <div class="sm:col-span-2 md:col-span-4">
                        <label for="form_taken_at_gas" class="<?php echo e($labelModalClasses); ?> mb-1">Waktu Pengambilan Sampel</label>
                        <input id="form_taken_at_gas" type="datetime-local" x-model="taken_at"
                               class="<?php echo e($inputModalClasses); ?>">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['taken_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="<?php echo e($errorModalClasses); ?>"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <?php
                    $bloodGasFields = [
                        ['id' => 'ph', 'label' => 'pH', 'step' => '0.001', 'placeholder' => '7.35-7.45'],
                        ['id' => 'pco2', 'label' => 'PCO₂', 'step' => '0.1', 'unit' => 'mmHg', 'placeholder' => '35-45'],
                        ['id' => 'po2', 'label' => 'PO₂', 'step' => '0.1', 'unit' => 'mmHg', 'placeholder' => '80-100'],
                        ['id' => 'hco3', 'label' => 'HCO₃', 'step' => '0.1', 'unit' => 'mEq/L', 'placeholder' => '22-26'],
                        ['id' => 'be', 'label' => 'BE', 'step' => '0.1', 'unit' => 'mEq/L', 'placeholder' => '-2 to +2'],
                        ['id' => 'sao2', 'label' => 'SaO₂', 'step' => '0.1', 'unit' => '%', 'placeholder' => '>95'],
                        ['id' => 'gula_darah', 'label' => 'Gula Darah', 'step' => '1', 'unit' => 'mg/dL', 'placeholder' => '70-140'],
                    ];
                    ?>

                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bloodGasFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <label for="form_gas_<?php echo e($field['id']); ?>" class="<?php echo e($labelModalClasses); ?>"><?php echo e($field['label']); ?>

                            <!--[if BLOCK]><![endif]--><?php if(isset($field['unit'])): ?><span class="text-xs text-gray-500 dark:text-gray-400">(<?php echo e($field['unit']); ?>)</span><?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </label>
                        <input id="form_gas_<?php echo e($field['id']); ?>" type="number"
                               step="<?php echo e($field['step']); ?>"
                               x-model="<?php echo e($field['id']); ?>"
                               placeholder="<?php echo e($field['placeholder'] ?? ''); ?>"
                               class="<?php echo e($inputModalClasses); ?>">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = [$field['id']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="<?php echo e($errorModalClasses); ?>"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 flex justify-end items-center space-x-3">
                <button type="button" @click="showBloodGasModal = false; resetForm()"
                        class="px-4 py-2 text-sm font-medium rounded-md
                               border border-gray-300 dark:border-gray-600
                               bg-white dark:bg-gray-700
                               text-gray-700 dark:text-gray-300
                               hover:bg-gray-50 dark:hover:bg-gray-600
                               focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500
                               dark:focus:ring-offset-gray-800
                               transition shadow-sm">
                    Batal
                </button>

                <button
                    type="button"
                    @click="$wire.saveBloodGasResult({
                        taken_at: taken_at,
                        gula_darah: gula_darah,
                        ph: ph,
                        pco2: pco2,
                        po2: po2,
                        hco3: hco3,
                        be: be,
                        sao2: sao2
                    }).then((success) => {
                        if (success) {
                            showBloodGasModal = false;
                            resetForm();
                        }
                    })"
                    wire:loading.attr="disabled" wire:target="saveBloodGasResult" wire:loading.class="opacity-75 cursor-wait"
                    class="inline-flex items-center px-4 py-2 text-sm font-medium rounded-md border border-transparent
                           bg-primary-600 text-white
                           hover:bg-primary-700
                           focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500
                           dark:focus:ring-offset-gray-800
                           transition shadow-sm">
                    <svg wire:loading wire:target="saveBloodGasResult" class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                    <span wire:loading.remove wire:target="saveBloodGasResult">Simpan Hasil</span>
                    <span wire:loading wire:target="saveBloodGasResult">Menyimpan...</span>
                </button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Karitas\monitoring-rs\resources\views/livewire/patient-monitor/partials/modal-gasdarah.blade.php ENDPATH**/ ?>