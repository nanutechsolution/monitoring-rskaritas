<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'title' => 'Riwayat Pemberian Obat',
'medications' => $medications,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'title' => 'Riwayat Pemberian Obat',
'medications' => $medications,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
use Carbon\Carbon;

$jamList = $medications->pluck('given_at')
    ->map(fn($t) => Carbon::parse($t)->format('H:i'))
    ->unique()
    ->sort()
    ->values();

$medNames = $medications->pluck('medication_name')->unique()->values();

$matrix = [];
foreach ($medications as $med) {
    $jam = Carbon::parse($med->given_at)->format('H:i');
    $matrix[$med->medication_name][$jam] = [
        'dose' => $med->dose,
        'route' => $med->route,
        'author' => $med->author_name, // Pastikan $med->author_name ada
        'nik' => $med->pegawai->nik ?? '-', // Ambil NIK jika ada relasi 'pegawai'
        'timestamp' => Carbon::parse($med->given_at)->translatedFormat('d M Y H:i'),
    ];
}

$highlightThreshold = 500; // Contoh threshold, sesuaikan jika perlu

// === KELAS HELPER UNTUK TEMA ===
$headerBg = 'bg-gray-100 dark:bg-gray-700';
$headerText = 'text-gray-700 dark:text-gray-300';
$headerStickyBg = 'bg-gray-100 dark:bg-gray-700';

$rowBg = 'bg-white dark:bg-gray-800';
$rowBgAlt = 'bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50';
$rowStickyBg = 'bg-white dark:bg-gray-800';
$rowStickyBgAlt = 'bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50';
$rowHover = 'hover:bg-primary-50 dark:hover:bg-gray-600 dark:hover:bg-opacity-50';

$border = 'border dark:border-gray-600';

?>

<div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden border border-gray-100 dark:border-gray-700">
    <div class="p-6">
        <div class="flex items-center justify-between border-b dark:border-gray-700 pb-3 mb-3">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100 flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-primary-600 dark:text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <?php echo e($title); ?>

            </h3>
            <span class="text-xs text-gray-400 dark:text-gray-500">Terakhir diperbarui: <?php echo e(now()->format('d M Y H:i')); ?></span>
        </div>

        <div class="overflow-x-auto border border-gray-200 dark:border-gray-700">
            <table class="min-w-max text-sm text-gray-700 dark:text-gray-300">
                <thead class="<?php echo e($headerBg); ?> <?php echo e($headerText); ?> uppercase text-xs tracking-wider sticky top-0 z-10">
                    <tr>
                        <th class="sticky left-0 <?php echo e($headerStickyBg); ?> px-4 py-3 text-left font-semibold z-10 <?php echo e($border); ?>">Obat</th>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $jamList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="<?php echo e($border); ?> px-4 py-3 font-semibold text-center"><?php echo e($jam); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $medNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="<?php echo e($loop->even ? $rowBgAlt : $rowBg); ?> <?php echo e($rowHover); ?> transition-colors duration-150">
                        <td class="sticky left-0 px-4 py-3 font-medium text-gray-800 dark:text-gray-100 <?php echo e($border); ?>

                                   <?php echo e($loop->even ? $rowStickyBgAlt : $rowStickyBg); ?> z-10">
                            <?php echo e($medName); ?>

                        </td>

                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $jamList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $data = $matrix[$medName][$jam] ?? null;
                            if ($data) {
                                $doseText = $data['dose'] . ' / ' . $data['route'];
                                $author = $data['author'];
                                $nik = $data['nik'];
                                $timestamp = $data['timestamp'];
                                preg_match('/\d+/', $data['dose'], $matches);
                                $highlightClass = (isset($matches[0]) && intval($matches[0]) > $highlightThreshold)
                                    ? 'text-danger-600 dark:text-danger-400 font-semibold'
                                    : 'text-gray-800 dark:text-gray-100';
                            } else {
                                $doseText = '-';
                                $author = null;
                                $highlightClass = 'text-gray-400 dark:text-gray-500';
                            }
                        ?>

                        <td class="px-4 py-3 text-center align-top <?php echo e($border); ?>">
                            <!--[if BLOCK]><![endif]--><?php if($data): ?>
                            <div class="<?php echo e($highlightClass); ?>"><?php echo e($doseText); ?></div>

                            <div class="text-xs text-gray-500 dark:text-gray-400 mt-1 relative group cursor-help">
                                <i class="fas fa-user-nurse text-primary-500 dark:text-primary-400 mr-1"></i>
                                <span><?php echo e(Str::limit($author, 15)); ?></span>

                                <div x-data="{ open: false }" x-show="open" x-transition @mouseenter="open = true" @mouseleave="open = false"
                                     class="hidden group-hover:block absolute z-20 bg-gray-800 dark:bg-gray-900 text-white
                                            text-xs rounded-md p-2 w-48 -translate-x-1/2 left-1/2 bottom-full mb-1 shadow-lg
                                            text-left">
                                    <p class="font-semibold"><?php echo e($author); ?></p>
                                    <p>NIK: <?php echo e($nik); ?></p>
                                    <p class="text-[11px] mt-1">Diberikan: <?php echo e($timestamp); ?></p>
                                </div>
                            </div>
                            <?php else: ?>
                            <span class="<?php echo e($highlightClass); ?>">-</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="<?php echo e($jamList->count() + 1); ?>" class="px-6 py-12 text-center text-gray-500 dark:text-gray-400 text-sm">
                            Belum ada data pemberian obat untuk siklus ini.
                        </td>
                    </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php /**PATH C:\Karitas\monitoring-rs\resources\views/livewire/patient-monitor/partials/output-tabel-obat.blade.php ENDPATH**/ ?>