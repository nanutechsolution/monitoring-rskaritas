<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Riwayat Gas Darah',
    'bloodGasResults' => $bloodGasResults,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Riwayat Gas Darah',
    'bloodGasResults' => $bloodGasResults,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
use Carbon\Carbon;

// --- Logika PHP Anda (Sudah Benar) ---
$params = [
    'Gula Darah' => 'gula_darah', 'pH' => 'ph', 'PCO₂' => 'pco2', 'PO₂' => 'po2',
    'HCO₃' => 'hco3', 'BE' => 'be', 'SaO₂' => 'sao2'
];

$jamList = $bloodGasResults->pluck('taken_at')
    ->map(fn($t) => Carbon::parse($t)->format('H:i'))
    ->unique()
    ->sort()
    ->values();

// === KELAS HELPER UNTUK TEMA ===
$headerBg = 'bg-gray-100 dark:bg-gray-700';
$headerText = 'text-gray-700 dark:text-gray-300';
$headerStickyBg = 'bg-gray-100 dark:bg-gray-700';

$rowBg = 'bg-white dark:bg-gray-800';
$rowBgAlt = 'bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50';
$rowStickyBg = 'bg-white dark:bg-gray-800';
$rowStickyBgAlt = 'bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50';
$rowHover = 'hover:bg-primary-50 dark:hover:bg-gray-600 dark:hover:bg-opacity-50';

$border = 'border dark:border-gray-600';

// Kelas Highlight/Badge
$badgeDanger = 'bg-danger-100 dark:bg-danger-900 dark:bg-opacity-50 text-danger-800 dark:text-danger-200 font-semibold';
$badgeSuccess = 'bg-green-100 dark:bg-green-900 dark:bg-opacity-50 text-green-800 dark:text-green-200';
$badgeNeutral = 'text-gray-700 dark:text-gray-300';
$badgeEmpty = 'text-gray-400 dark:text-gray-500';

?>

<div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden border border-gray-100 dark:border-gray-700">
    <div class="p-6">
        <h3 class="text-lg font-semibold text-primary-700 dark:text-primary-300 flex items-center gap-2 border-b border-gray-200 dark:border-gray-700 pb-3 mb-3">
            <svg class="w-5 h-5 text-danger-600 dark:text-danger-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-3-3v6m-6 3h12a2 2 0 002-2V8a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
            </svg>
            <?php echo e($title); ?>

        </h3>

        <!--[if BLOCK]><![endif]--><?php if($bloodGasResults->isEmpty()): ?>
            <p class="text-gray-500 dark:text-gray-400 text-center py-10">Belum ada data gas darah untuk siklus ini.</p>
        <?php else: ?>
        <div class="overflow-x-auto border border-gray-200 dark:border-gray-700 scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600 scrollbar-track-gray-100 dark:scrollbar-track-gray-700">
            <table class="min-w-full border-collapse text-sm">
                <thead class="text-xs <?php echo e($headerText); ?> uppercase <?php echo e($headerBg); ?> sticky top-0 z-10">
                    <tr>
                        <th class="sticky left-0 <?php echo e($headerStickyBg); ?> px-4 py-3 text-left font-semibold z-10 <?php echo e($border); ?>">Parameter</th>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bloodGasResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="<?php echo e($border); ?> px-4 py-1 text-center">
                            <?php echo e(\Carbon\Carbon::parse($result->taken_at)->format('H:i')); ?><br>
                            <span class="text-xs text-gray-500 dark:text-gray-400 font-normal italic mt-0.5"><?php echo e($result->author_name); ?></span>
                        </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $params; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e($loop->even ? $rowBgAlt : $rowBg); ?> <?php echo e($rowHover); ?>">
                        <td class="sticky left-0 px-4 py-2 font-semibold <?php echo e($border); ?> z-10
                                   <?php echo e($loop->even ? $rowStickyBgAlt : $rowStickyBg); ?>

                                   text-gray-900 dark:text-gray-100">
                            <?php echo e($label); ?>

                        </td>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bloodGasResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $value = $result->$field;
                            $badge = $badgeNeutral; // Default
                            if($value !== null) {
                                if($field == 'gula_darah') $badge = $value > 140 ? $badgeDanger : $badgeSuccess;
                                elseif($field == 'ph') $badge = ($value < 7.35 || $value > 7.45) ? $badgeDanger : $badgeSuccess;
                                elseif($field == 'sao2') $badge = $value < 95 ? $badgeDanger : $badgeSuccess;
                            } else {
                                $value = '-';
                                $badge = $badgeEmpty;
                            }
                        ?>
                        <td class="<?php echo e($border); ?> px-4 py-2 text-center <?php echo e($badge); ?>"><?php echo e($value); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\Karitas\monitoring-rs\resources\views/livewire/patient-monitor/partials/output-tabel-gasdarah.blade.php ENDPATH**/ ?>