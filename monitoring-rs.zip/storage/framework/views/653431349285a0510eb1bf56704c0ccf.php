<div class="space-y-6">
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden animate-pulse">

        
        <div class="p-4 border-b border-gray-200 dark:border-gray-700">
            <div class="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
        </div>

        
        <div class="overflow-x-auto">
            <table class="min-w-full">
                
                <thead class="bg-gray-100 dark:bg-gray-700">
                    <tr>
                        <th class="p-6 left-0 px-3 py-3">
                            <div class="h-5 bg-gray-300 dark:bg-gray-600 rounded w-24"></div>
                        </th>
                        <th class="px-2 py-3 text-center">
                            <div class="h-5 bg-gray-300 dark:bg-gray-600 rounded w-16 mx-auto"></div>
                        </th>
                        <th class="px-2 py-3 text-center">
                            <div class="h-5 bg-gray-300 dark:bg-gray-600 rounded w-16 mx-auto"></div>
                        </th>
                        <th class="px-2 py-3 text-center">
                            <div class="h-5 bg-gray-300 dark:bg-gray-600 rounded w-16 mx-auto"></div>
                        </th>
                    </tr>
                </thead>
                
                <tbody class="text-gray-700 dark:text-gray-300">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = range(1, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e($loop->even ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-700 dark:bg-opacity-50'); ?>">
                        <td class="px-3 py-3 border-t dark:border-gray-700">
                            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-32"></div>
                        </td>
                        <td class="px-2 py-3 text-center border-t dark:border-gray-700">
                            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-12 mx-auto"></div>
                        </td>
                        <td class="px-2 py-3 text-center border-t dark:border-gray-700">
                            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-12 mx-auto"></div>
                        </td>
                        <td class="px-2 py-3 text-center border-t dark:border-gray-700">
                            <div class="h-4 bg-gray-200 dark:bg-gray-700 rounded w-12 mx-auto"></div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\Karitas\monitoring-rs\resources\views/livewire/placeholders/observasi-table-skeleton.blade.php ENDPATH**/ ?>