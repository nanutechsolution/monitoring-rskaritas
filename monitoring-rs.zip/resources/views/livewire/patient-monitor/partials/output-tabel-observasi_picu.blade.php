<livewire:observasi-table-picu :cycleId="$currentCycleId" />
