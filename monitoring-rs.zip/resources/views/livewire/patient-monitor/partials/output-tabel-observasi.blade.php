<livewire:observasi-table :cycleId="$currentCycleId" />
