<?php

namespace App\Livewire\PatientMonitor;

use Livewire\Component;

class NicuInputForm extends Component
{
    public function render()
    {
        return view('livewire.patient-monitor.nicu-input-form');
    }
}
